# Planung einer Reise nach Italien

Italien ist eines der beliebtesten Reiseziele in Europa und bekannt für seine reiche Geschichte, kulturellen Schätze und atemberaubende Landschaften. Diese Reise führt uns durch die Highlights des Landes, von den historischen Ruinen Roms bis zu den romantischen Kanälen Venedigs. In diesem Plan werden die wichtigsten Aspekte der Reise detailliert dargestellt, einschließlich Budget, Unterkünfte, Tagesabläufe und geplante Aktivitäten.

# 2.Reise planung
## 2.1 Reisedaten und Zielorte

Die Reise beginnt am **15. August 2025** und endet am **25. August 2025.** Auf dieser 10-tägigen Tour werden wir drei bedeutende Städte Italiens besuchen:

- Rom
- Florenz 
- Venedig

## Reisebudget

Das Gesamtbudget für die Reise beträgt **2.500€**. Die folgende Tabelle gibt einen Überblick über die geplanten Ausgaben:

|**Kategorie** |**Budget in €**|
|:--|:--|
|Flug|*600€*|
|Unterkunft|*1000€*|
|Verpflegung|*400€*|
|Aktivitäten|*300€*|
|Transport|*Transport	200€*|


Es ist wichtig, sich an das Budget zu halten, um unerwartete Ausgaben zu vermeiden.***Alle Buchungen sollten im Voraus vorgenommen werden, um Kosten zu sparen.***


## 3.Unterkünfte
Für die Unterkünfte haben wir eine Mischung aus Airbnbs und Hotels gewählt. Dies bietet Flexibilität und ermöglicht es, verschiedene Erfahrungen zu sammeln.

- **Rom:** Airbnb Rom Zentrum:  400€ für 4 Nächte
- **Florenz:** [HotelSantaMariaNvella](https://www.youtube.com/watch?v=dQw4w9WgXcQ) 350€ für 3 Nächte
- **Venedig:** Airbnb Venedig Kanalblick: 250€ für 3 Nächte

## 4. Tagesablauf

Der Tagesablauf hilft uns, die Zeit optimal zu nutzen und sicherzustellen, dass wir alle wichtigen Sehenswürdigkeiten besuchen. Hier eine grobe Übersicht der ersten Tage:

### Tag 1: Ankunft in Rom

+ Flug von Frankfurt nach Rom   (10:00 Uhr - 12:00 Uhr)

+ Check-In Airbnb Rom
+ Erkundung des Kolosseums
+	Abendessen im Restaurant „La Pergola“

### Tag 2: Rom entdecken
+ Besuch des Vatikans und des Petersdoms
+ Spaziergang durch die Altstadt
+ Abends: Piazza Navona

### Tag 3-4: Weiterreise nach Florenz
+ Fahrt mit dem Zug nach Florenz (ca. 1,5 Stunden)
+ Besuch der Uffizien und der Ponte Vecchio

Die verbleibenden Tage in Venedig werden flexibel gestaltet, mit der Möglichkeit, eine Gondelfahrt durch die berühmten Kanäle zu unternehmen und die malerische Stadt zu erkunden.

## 5. Aktivitäten und Ausflüge

Jede Stadt bietet einzigartige Aktivitäten, die wir in den Reiseplan integriert haben:

**Rom:**

+ Erkundung des Kolosseums
* Besichtigung des Pantheon
* Besuch des Trevi-Brunnens
- Entspannen im Park der Villa Borghese

**Florenz**

+ Besuch der berühmten Uffizien
+ Spaziergang über die Ponte Vecchio
+ 	Tagesausflug nach Pisa, um den schiefen Turm zu sehen

**Venedig:**

+ Gondelfahrt durch die Kanäle
+ Markusplatz und Markusdom besuchen
+ Besuch der Insel Murano, bekannt für ihre Glaskunst


##  6. Zusätzliche Notizen

Hier einige wichtige Punkte, die vor und während der Reise zu beachten sind:

### Dokumente:

+ Reisepass
+ Impfpass
+ Kreditkarten

### Packliste:

- Reisepass
- Sonnencreme
- Bequeme Schuhe
- Kamera

## To-Do vor Abreise:

[x] Auslandskrankenversicherung abschließen

[x]Reiseapotheke packen

[x] Wichtige italienische Phrasen lernen

[x] Adapter für Steckdosen Typ L besorgen


--------------------------------
>„Italien - wo Geschichte auf Kultur trifft!“
--------------------------------


### Bilder 

#### ROM
![Rom](https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ftse1.mm.bing.net%2Fth%3Fid%3DOIP.nJl_Ae9CivE-zQ4Iyk8bOQHaE8%26cb%3Diwc2%26pid%3DApi&f=1&ipt=cfdb650bfcfe580762246982c77868e1c94ae525ed653183dbb21a48cadf5826&ipo=images)

#### Florenz
![Florenz](https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fwww.urlaubsguru.de%2Fwp-content%2Fuploads%2F2016%2F02%2Fbeautiful-cityscape-skyline-of-firenze-florence-italy-with-the-bridges-over-the-river-arno-shutterstock_445227091.jpg&f=1&nofb=1&ipt=2b51f0be8d3bc5efff265675a3dec788ce4f9c10dc70562cb85b651e2b576d60)

#### Venedig
![Venedig](https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fescapeaway.imgix.net%2Fitalien%2Fveneto%2Fvenedig%2Fshutterstock_88847704.8925b9bb-c955-418d-8143-1d949d266d78.jpg&f=1&nofb=1&ipt=382e85e6da61f6d5fa714351e69335b89f14b6c0d446e10325fe27af1ac590f7)

#### Italien
![Italien](https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fcdn.urlaubsguru.at%2Fwp-content%2Fuploads%2F2018%2F01%2Fshutterstock_257301595.jpg&f=1&nofb=1&ipt=702dd8e623a6a5f7382f0d467118002c45965c4ae98895f33a4c7847419e3945)