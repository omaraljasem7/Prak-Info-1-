# Aufgabe 2

**Nennen Sie drei Moeglichkeiten, CSS-Code in eine HTML-Datei einzubinden. Erklaeren Sie Vor- undNachteile jeder der drei Moeglichkeiten**


#### Lösung
Die drei Möglichkeiten eine ***CSS*** Datai in eine ***HTML*** Datei einzu binden sind :

**1. Inline CSS:**
+ Vorteile:
    - eigenet sich gut für eine kleine datei und kein groeß datei oder projekt 
    - gitl nur für das jeweilige Element
-  Nachteil
   -  eigent sich nicht für große datei oder projekt
   -  erfordert mehr Arbeit
   -  gilt nicht für alle Elemente in der Datei


**2.Internal CSS** 
 + Vorteil:
   + eigent sich für eine seite 
   + gilt für alle Elemente in der Datei
   + gut für kleines Projekt oder Datei
 + Nachteil:
   + Nicht gut für ein großes Projekt oder Datei

**3. External CSS**
+ Vorteil:
  + gilt für alle Dateien im Projekt 
  + bessere Uebersicht
  + eine Anderung zeilt auf alle Dateien die,die die Datei eingebunden haben
  + gute Skallierbarkeit
+ Nachteil:
  * Es gibt meiner Meinung nach keine Nachteile

### Fazit: 
**Best Use -> External CSS**